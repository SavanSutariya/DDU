using System;
using System.Collections.Generic;
					
public class Program
    {
        public static void Main()
        {
            int sum = Calculator.Add(100, 100);
            Console.WriteLine(sum);
            Console.ReadKey();
        }

    }
    public class Calculator
    {
       // [ObsoleteAttribute("Use Add(List <int> Numbers) Method")]
       [ObsoleteAttribute("Obsolete Method")]


        public static int Add(int n1, int n2)
        {
            //int sum = 0;

            return n1 + n2;
        }
        /*public static int Add(List<int> Numbers)
        {
            int sum = 0;
            foreach (int number in Numbers)
            {
                sum = sum + number;
            }
            return sum;
        }*/
    }

