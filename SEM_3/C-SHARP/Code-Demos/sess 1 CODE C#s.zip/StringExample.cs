using System;  
public class StringExample  
{  
    public static void Main(string[] args)  
    {  
        string s1 = "hello";  
  
        char[] ch = { 'c', 's', 'h', 'a', 'r', 'p' };  
        string s2 = new string(ch);  
         
        Console.WriteLine(s1);  
        Console.WriteLine(s2); 

	string str = "HelloWorld"; 
          
        // using Chars[Int32] & Length property 
        for (int i = 0; i <= str.Length - 1; i++) 
            Console.Write("{0} ", str[i]);  
    }  
}  

