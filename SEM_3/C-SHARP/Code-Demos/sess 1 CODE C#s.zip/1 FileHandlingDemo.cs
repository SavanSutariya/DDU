
using System.IO;  
namespace FileHandlingDemo
{
  public class Example
 {
   public static void Main(string[] args)  
   {
       FileStream fi = new FileStream("e:\\file.txt", FileMode.OpenOrCreate);
       fi.WriteByte(12);
       fi.WriteByte(6);
       fi.WriteByte(30);
       fi.Close();  
       FileStream fo = new FileStream("e:\\file.txt", FileMode.OpenOrCreate);
       int i = 0;  
       Console.WriteLine("The contents of the file are:");
       while ((i = fo.ReadByte()) != -1)  
       {
           Console.WriteLine(i);  
       }
       fo.Close();  
   }
 }
}