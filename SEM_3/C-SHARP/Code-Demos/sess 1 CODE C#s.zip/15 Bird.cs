using System;
 
class Bird {
 
}
 
// Creating a sealed class
sealed class Test : Bird {
}
 
// Inheriting the Sealed Class
class Example : Test {
}
 
// Driver Class
class Program {
 
    // Main Method
    static void Main()
    {
    }
}