using System;  
using System.IO;  
namespace FileHandlingDemo
{  
   class Example
   {
       static void Main(string[] args)  
       {
           StringWriter sw = new StringWriter();  
           sw.WriteLine("File Handling in C#");  
           sw.WriteLine("StringReader Class and StringWriter Class");
           sw.Close();
           StringReader sr = new StringReader(sw.ToString());  
           while (sr.Peek() > -1)  
           {
               Console.WriteLine(sr.ReadLine());  
           }
       }
   }
}