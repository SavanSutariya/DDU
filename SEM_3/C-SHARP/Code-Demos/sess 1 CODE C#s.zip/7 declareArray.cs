public class declareArray
{
	public static void Main()
	{
		int[] intArray1 = new int[5]; 
		
		int[] intArray2 = new int[5]{1, 2, 3, 4, 5};		
		
		int[] intArray3 = {1, 2, 3, 4, 5};
		string[] strArray1, strArray2;
		
		strArray1 = new string[5]{ "1st Element",
			   "2nd Element", 
			   "3rd Element",
			   "4th Element",
			   "5th Element" 
		};
		strArray2 = new string[]{ "1st Element",
			   "2nd Element",
			   "3rd Element",
			   "4th Element", 
			   "5th Element" 
		};
		Console.WriteLine(strArray1.Length);
		Console.WriteLine(strArray2.Length);
	}
}