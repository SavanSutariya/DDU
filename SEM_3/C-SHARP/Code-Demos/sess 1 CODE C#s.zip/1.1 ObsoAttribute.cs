using System;
namespace AttributesDemo
{
   class Example
   {
       static void Main(string[] args)
       {
           Console.WriteLine("Program for Attributes");
           DemoMethod();
       }
       [Obsolete("Don't use the DemoMethod()",false)]
       public static void DemoMethod()
       {
           Console.WriteLine("Inside DemoMethod()");  
       }
   }
}