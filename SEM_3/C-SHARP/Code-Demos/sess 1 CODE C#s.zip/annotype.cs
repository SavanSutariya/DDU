using System;

public class annotype
{
	public static void Main()
	{
		 // Creating and initializing anonymous object 
        var anony_object = new {s_id = 109, 
                                s_name = "Geet",  
                               language = "C#" }; 
  
        // Accessing the object properties 
        Console.WriteLine("Student id: " + anony_object.s_id); 
        Console.WriteLine("Student name: " + anony_object.s_name); 
        Console.WriteLine("Language: " + anony_object.language); 
	}
}

/*
Student id: 109
Student name: Geet
Language: C#
*/
