using System;  
using System.IO;  
namespace FileHandlingDemo
{  
   class Example
   {
       static void Main(string[] args)  
       {
           using (TextWriter tw = File.CreateText("e:\\file2.txt"))  
           {
               tw.WriteLine("C# File Handling");
               tw.WriteLine("TextReader Class and TextWriter Class");  
           }
           using (TextReader tr = File.OpenText("e:\\file.txt"))  
           {
               Console.WriteLine(tr.ReadToEnd());  
           }
       }
   }
}