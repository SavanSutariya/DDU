using System;

public class Student{

	public string StudentName { get; set; }
	
}

public class reftype{
	public static void ChangeReferenceType(Student std2)	{
		std2.StudentName   = "Steve";
	}
	
	public static void Main()	{
		Student std1 = new Student();
		
		std1.StudentName = "Bill";
		
		ChangeReferenceType(std1);
	
		Console.WriteLine(std1.StudentName);
	}
}

/*
Steve
*/