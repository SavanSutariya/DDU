using System;


class unsafeCode
    {
       unsafe  static void Main(string[] args)
        {
            
            {
                int ab = 32;
                int* p = &ab;
                Console.WriteLine("value of ab is {0}", *p);
                Console.ReadLine();
            }
        }
    }