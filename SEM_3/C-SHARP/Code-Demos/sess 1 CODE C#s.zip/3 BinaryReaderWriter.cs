using System;  
using System.IO;  
namespace FileHandlingDemo
{  
   class Example
   {
       static void Main(string[] args)  
       {
           string fName = "F:\\file4.TXT";  
           using (BinaryWriter bw = new BinaryWriter(File.Open(fName, FileMode.Create)))  
           {
                bw.Write("File Handling in C#");  
                bw.Write("BinaryReader class and BinaryWriter class");
           }
       using (BinaryReader br = new BinaryReader(File.Open("F:\\file4.TXT", FileMode.Open)))  
           {
               Console.WriteLine(br.ReadString());  
               Console.WriteLine(br.ReadString());  
           }
       }
   }
}