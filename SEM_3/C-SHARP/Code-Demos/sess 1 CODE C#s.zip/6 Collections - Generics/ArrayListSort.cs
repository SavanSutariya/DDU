using System;
using System.Collections;
using System.Collections.Generic;

public class ArrayListSort      {  

      public static void Main(string[] args)  
        {  
            ArrayList personList = new ArrayList();  
            personList.Add("Sandeep");  
            personList.Add("Raviendra");  
            personList.Add("Vinit");  
            personList.Add("Lokesh");  
            personList.Add("Prateek");  
            Console.WriteLine("=========== Original List================");  
            PrintValues(personList);  
            //sort the list  
            personList.Sort();  
            Console.WriteLine("=========== Sorted List================");  
            PrintValues(personList);  
	//Console.Read();  
  
        }  
        private static void PrintValues(IEnumerable myList)  
        {  
            foreach (Object obj in myList)  
            {  
                Console.WriteLine("Name is: {obj}"+ obj);  
            }  
        }  
    } 
