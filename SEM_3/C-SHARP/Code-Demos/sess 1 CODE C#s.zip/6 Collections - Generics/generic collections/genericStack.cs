using System;
using System.Collections.Generic;

public class genericStack {  
        public static void Main(string[] args) {  
            Stack < string > stack1 = new Stack < string > ();  
            stack1.Push("************");  
            stack1.Push("MCA");  
            stack1.Push("MBA");  
            stack1.Push("BCA");  
            stack1.Push("BBA");  
           /* stack1.Push("***********");  
            stack1.Push("**Courses**");  
            stack1.Push("***********");  */
            Console.WriteLine("The elements in the stack1 are as:");  
            foreach(string s in stack1) {  
                Console.WriteLine(s);  
            }  
            //For remove/or pop the element pop() method is used  
            stack1.Pop();  
            stack1.Pop();  
            stack1.Pop();  
            Console.WriteLine("After removal/or pop the element the stack is as:");  
            //the element that inserted in last is remove firstly.  
            foreach(string s in stack1) {  
                Console.WriteLine(s);  
            }  
	    Console.WriteLine("The peek element is:" + stack1.Peek());  
            stack1.Pop();  
            Console.WriteLine("The next peek element is:" + stack1.Peek());
        }  
}

/*

The elements in the stack1 are as:
***********
**Courses**
***********
BBA
BCA
MBA
MCA
************
After removal/or pop the element the stack is as:
BBA
BCA
MBA
MCA
************
The peek element is:BBA
The next peek element is:BCA

*/  
