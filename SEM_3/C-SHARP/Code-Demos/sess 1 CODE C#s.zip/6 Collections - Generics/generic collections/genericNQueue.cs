public class genericNQueue{

    public static void Main() { 
  
        // Creating a Queue 
        Queue < string > myQueue = new Queue < string > ();  
  
        // Inserting the elements into the Queue 
        myQueue.Enqueue("C#"); 
        myQueue.Enqueue("PHP"); 
        myQueue.Enqueue("Perl"); 
        myQueue.Enqueue("Java"); 
        myQueue.Enqueue("C"); 
  
        // Displaying the count of elements 
        // contained in the Queue 
        Console.Write("Total number of elements present in the Queue are: "); 
  
        Console.WriteLine(myQueue.Count); 
  
        // Displaying the beginning element of Queue 
        Console.WriteLine("Beginning Item is: " + myQueue.Peek());
	Console.WriteLine("Peek the first item from the queue is:" + myQueue.Peek());  
        myQueue.Dequeue();  
        Console.WriteLine("Peek the next item from the queue is:" + myQueue.Peek());  

	/*myQueue.Clear();  
        Console.WriteLine("The elements in the queue are after the clear method:" + myQueue.Count);      */
	Queue < string > queue1 = newQueue < string > (myQueue.ToArray());  
        Console.WriteLine("\nContents of the copy");  
        foreach(string n in queue1) {  
                Console.WriteLine(n);  
        }  
    } 
}

/*
Total number of elements present in the Queue are: 5
Beginning Item is: C#
Peek the first item from the queue is:C#
Peek the next item from the queue is:PHP
Contents of the copy
PHP
Perl
Java
C
The elements in the queue are after the clear method:0
*/
