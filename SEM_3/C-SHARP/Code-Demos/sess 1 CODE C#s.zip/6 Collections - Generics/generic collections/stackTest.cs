using System;
using System.Collections.Generic;  
using System.Text;

class stackTest {
    // a function with the unsafe modifier is called from a normal function
        static void Main(string[] args)
        {
            Stack<int> numbersStack = new Stack<int>();
            numbersStack.Push(1);
            numbersStack.Push(2);
            numbersStack.Push(3);

            int topElement = numbersStack.Pop();
            Console.WriteLine(topElement);
            Console.Read();
        }
        // Generic class to accept all types of data types  
       
}