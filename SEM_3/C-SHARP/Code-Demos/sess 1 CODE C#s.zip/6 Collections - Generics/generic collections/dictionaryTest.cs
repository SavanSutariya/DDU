using System;
using System.Collections.Generic;

public class dictionaryTest {

    public static void Main()     { 
   // Create a dictionary with string key and Int16 value pair    
    Dictionary<string, Int16> AuthorList = new Dictionary<string, Int16>();    
    AuthorList.Add("K Munshi", 35);    
    AuthorList.Add("Dr. Kalaam", 25);    
    AuthorList.Add("Ameesh", 29);    
    AuthorList.Add("Jay V.", 21);    
    AuthorList.Add("M K Gandhi", 84);    
    AuthorList.Add("Jane Austin", 84);    
    // Count    
    Console.WriteLine("Count: {0}", AuthorList.Count);    
    // Set Item value    
    AuthorList["Rajmohan Gandhi"] = 9;    
    if (!AuthorList.ContainsKey("Ameesh"))        {    
        AuthorList["Ameesh"] = 20;    
    }    
    if (!AuthorList.ContainsValue(9))        {    
        Console.WriteLine("Item found");    
    }    
    // Remove item with key = 'Jane Austin'    
    AuthorList.Remove("Jane Austin");      
    // Read all items    
    Console.WriteLine("Authors all items:");    
    foreach (KeyValuePair<string, Int16> author in AuthorList)        {    
        Console.WriteLine("Key: {0}, Value: {1}",    
        author.Key, author.Value);    
    }    
      
    // Remove all items    
    AuthorList.Clear();  
    } 
}

/*
Count: 6
Authors all items:
Key: K Munshi, Value: 35
Key: Dr. Kalaam, Value: 25
Key: Ameesh, Value: 29
Key: Jay V., Value: 21
Key: M K Gandhi, Value: 84
Key: Jane Austin, Value: 84
Key: Rajmohan Gandhi, Value: 9

*/


