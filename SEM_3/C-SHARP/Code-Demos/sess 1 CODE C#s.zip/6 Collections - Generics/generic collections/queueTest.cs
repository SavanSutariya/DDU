using System;
using System.Collections.Generic;  
using System.Text;

class queueTest {
    // a function with the unsafe modifier is called from a normal function
        static void Main(string[] args)
        {
            Queue<string> tasks = new Queue<string>();
            tasks.Enqueue("Task 1");
            tasks.Enqueue("Task 2");

            string currentTask = tasks.Dequeue();
            Console.WriteLine(currentTask);
            Console.Read();
        }
        // Generic class to accept all types of data types  
       
}
