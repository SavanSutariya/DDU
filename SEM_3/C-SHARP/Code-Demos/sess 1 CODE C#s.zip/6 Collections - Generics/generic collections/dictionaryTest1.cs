using System;
using System.Collections.Generic;  
using System.Text;

class dirTest {
    // a function with the unsafe modifier is called from a normal function
        static void Main(string[] args)
        {
           Dictionary<string, int> ages = new Dictionary<string, int>();
            ages["John"] = 30;
            ages["Alice"] = 25;

            int johnsAge = ages["John"];
            Console.WriteLine(ages["Alice"]);
            Console.WriteLine(johnsAge);
            Console.Read();
        }
        // Generic class to accept all types of data types  
       
}