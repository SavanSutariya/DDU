using System;

namespace MyCompiler {
   
public class GenericClass<T>
{
    private T value;

    public GenericClass(T value)
    {
        this.value = value;
    }

    public T GetValue()
    {
        return value;
    }
}
public class GenericMethods
{
    public T Max<T>(T first, T second) where T : IComparable<T>
    {
        return first.CompareTo(second) >= 0 ? first : second;
    }
}
public class testGeneric{
	public static void Main(){
		GenericClass<int> intGeneric = new GenericClass<int>(10);
		int intValue = intGeneric.GetValue();

		GenericMethods genericMethods = new GenericMethods();
		int maxResult = genericMethods.Max(5, 8); // Result: 8
		string maxStringResult = genericMethods.Max("apple", "orange");
		Console.WriteLine(maxResult);
		Console.WriteLine(maxStringResult);
		
	}
}
}