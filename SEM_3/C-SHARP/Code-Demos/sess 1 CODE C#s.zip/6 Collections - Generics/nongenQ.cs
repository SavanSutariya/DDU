using System;
using System.Collections;
  
public class nongenQue {
    static public void Main()
    {
  
        // Create a queue
        // Using Queue class
        Queue my_queue = new Queue();
  
        // Adding elements in Queue
        // Using Enqueue() method
        my_queue.Enqueue("c#");
        my_queue.Enqueue(1);
        my_queue.Enqueue(100);
        my_queue.Enqueue(null);
        my_queue.Enqueue(2.4);
        my_queue.Enqueue("PHP");
  
        // Accessing the elements
        // of my_queue Queue
        // Using foreach loop
        foreach(var ele in my_queue)
        {
            Console.WriteLine(ele);
        }
        Console.WriteLine("Total elements present in my_queue: {0}",
	                                                    my_queue.Count);
	// Obtain the topmost element of my_queue
	Console.WriteLine("Topmost element of my_queue is: {0}",
                                               my_queue.Peek());
	// Remove all the elements from the queue
	//my_queue.Clear();
	  
	// After Clear method
	Console.WriteLine("Total elements present in my_queue: {0}", my_queue.Count);
	
	 if (my_queue.Contains("PHP") == true) {
	            Console.WriteLine("Element available...!!");
	 }
	 else {
	            Console.WriteLine("Element not available...!!");
        }
    }
}