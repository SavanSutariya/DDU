using System;
using System.Collections;
using System.Collections.Generic;

public class ArrayListTest    {  
       public static void Main(string[] args)          {  
           ArrayList resultList = new ArrayList();  
           resultList.Add(90);  
           resultList.Add(95);  
		   
	   foreach (var item in resultList)  {  
	       // string arrayItem = string.Format("Name  is {item}"+ item);  
	        Console.WriteLine(item);  
        } 
	ArrayList personList= new ArrayList();  
        personList.Add("Sandeep");  
        personList.Add("Raviendra");  
        
		personList.Insert(1,"Shailja");  
		for (int i = 0; i < personList.Count; i++){  
            	Console.WriteLine(personList[i]);  
        }
	    Console.WriteLine("After Remove...");  
		personList.Remove("Sandeep");
		personList.RemoveAt(0);
		personList.Add("Rahul");   
		personList.Add("Raaj");   
		personList.Add("Abhi");   
	   //	int totalItems = personList.Count;  
        	Console.WriteLine("Total items:"+personList.Count);
		personList.RemoveRange(0, 2);
		   
		foreach (var item in personList)  {  
	        Console.WriteLine(item);  
        }
        Console.WriteLine("Total items after remove range:"+personList.Count);
		personList.Clear();  
        Console.WriteLine("Total items after clear:"+personList.Count);

    }  
}  
