using System;
using System.Collections;
 
class nongenStack{
   
    static public void Main()
    {
 
        // Create a stack
        // Using Stack class
        Stack my_stack = new Stack();
 
        // Adding elements in the Stack
        // Using Push method
        my_stack.Push("C#");
        my_stack.Push(2.27);
        my_stack.Push("PHP");
        my_stack.Push(null);
        my_stack.Push('H');
        my_stack.Push(7284);
        
 
        // Accessing the elements
        // of my_stack Stack
        // Using foreach loop
        foreach(var elem in my_stack)
        {
            Console.WriteLine(elem);
        }
    }
}