using System;
using System.Collections.Generic;  
using System.Text;

class hashTest {
    // a function with the unsafe modifier is called from a normal function
        static void Main(string[] args)
        {
           HashSet<int> uniqueNumbers = new HashSet<int>();
            uniqueNumbers.Add(1);
            uniqueNumbers.Add(2);
            uniqueNumbers.Add(1); // This will not add a duplicate element.

            int numberOfUniqueElements = uniqueNumbers.Count;
            Console.WriteLine(numberOfUniqueElements);
            Console.Read();
        }
        // Generic class to accept all types of data types  
       
}
