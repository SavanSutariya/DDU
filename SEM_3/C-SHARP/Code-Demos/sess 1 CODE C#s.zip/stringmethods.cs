using System;

public class stringmrthods{
	public static void Main()	{
		string str1 = "HelloWorld"; 
		//from string literal and string concatenation
         string str2 = (String)str1.Clone(); 
         
        // Displaying both the string 
        Console.WriteLine("String : {0}", str1); 
        Console.WriteLine("Clone String : {0}", str2);
		
		string upperstr1 = str1.ToUpper(); 
        Console.WriteLine("Upper String: {0}",upperstr1); 
		
		string lowerstr1 = str1.ToLower(); 
        Console.WriteLine("Lower String: {0}", lowerstr1); 
		
		str2 = String.Copy(str1); 
		Console.WriteLine("Copy String: {0}", str2); 
		String s1="hello";
		String s2="Hello";
		Console.WriteLine(str1.Contains(s1)); 
  
        // Here case-sensitive comparision 
        // And substr2 value is 'For' 
        // So its return false 
        Console.WriteLine(str1.Contains(s2)); 
		
		bool x,y;
		x = s1.EndsWith("lo"); 
        	y = s2.EndsWith("World"); 
		Console.WriteLine(x.ToString());
		Console.WriteLine(y.ToString());
		int index1 = s1.IndexOf('l');
		int index2 = s2.IndexOf('d', 4);
		int index3 = str1.IndexOf('r', 3, 7); 
		int index4 = str1.IndexOf("World"); 
		Console.WriteLine("The Index Value of character 'l' is " + index1);
		Console.WriteLine("The Index Value of character 'd' is " + index2);
		Console.WriteLine("The Index Value of character 'r' is " + index3);
		Console.WriteLine("The Index Value of character 'r' is " + index4);

		Console.WriteLine("New string: " + str1.Insert(5, "Morning"));
		Console.WriteLine("Hey Started".Insert(3, " Its now"));

		s1 = "Have a nice day";
		s2="BrightSunnyDay";
		Console.WriteLine("New String s11 after remove : " + s1.Remove(3));
		Console.WriteLine("New String s2 after remove : " + s2.Remove(5, 3));

		Console.WriteLine("NewString s1 after replace: " + s1.Replace('H', 'P'));
		Console.WriteLine("NewString s2 after replace: " + s2.Replace('S', ' '));
		Console.WriteLine("NewString s2 after replace: " + s2.Replace("Day", "Days"));
		s1="abcdef";
		s1 = s1.Replace('a', 'b').Replace('b', 'x').Replace('x', 'z');
		Console.WriteLine("s1 after replace chain:"+s1);

		object[] array = {"Hello", "World", 12345, 6789, "Good", "MCA"};
		string s3 = string.Join(", ", array);
		//string s3 = string.Join("/ ", array);
		Console.WriteLine("Value of string  s3 is " + s3); 
		bool result1, result2; 
  		s1="abc"; s2="abf";
        	result1 = s1 == s2; 
	        result2 = s1 != s2; 
        	Console.WriteLine("Equality Check:"+result1); 
        	Console.WriteLine("InEquality Check:"+result2); 
	            Console.ReadKey();
    } 

	
}
