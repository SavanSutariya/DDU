using System;

namespace MyCompiler {
    public class Dollar{
    public decimal Amount { get; }

    public Dollar(decimal amount)     {
        Amount = amount;
    }
    // Implicit conversion from Dollar to Euro
    public static implicit operator Euro(Dollar dollar)     {
        decimal conversionRate = 0.85m; // Conversion rate
        return new Euro(dollar.Amount * conversionRate);
    }        
}

    public class Euro{
    public decimal Amount { get; }

    public Euro(decimal amount)    {
        Amount = amount;
    }

    // Explicit conversion from Euro to Dollar
    public static explicit operator Dollar(Euro euro)    {
        decimal conversionRate = 1.18m; // Conversion rate
        return new Dollar(euro.Amount * conversionRate);
    }
    }
    public class currency{
       public static void Main(){
       
        Dollar dollars = new Dollar(100m);
        Euro euros = dollars; // Implicit conversion
        Dollar convertedDollars = (Dollar)euros; // Explicit conversion
        Console.WriteLine(convertedDollars.Amount);
        Console.WriteLine(euros.Amount);
    }
}
    
}