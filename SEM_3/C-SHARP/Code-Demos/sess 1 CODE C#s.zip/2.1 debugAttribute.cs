//#define DEBUG 

using System;
using System.Collections.Generic;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        List<string> l = new List<string>();
        l.Add("rabbit");
        l.Add("bird");
        AddToArray(l);
        Console.WriteLine("Elements: {0}", l.Count);
    }
    
    [Conditional("DEBUG")]
    static void AddToArray(List<string> l)
    {
        // New array
        string[] a = new string[2];
        a[0] = "cat";
        a[1] = "mouse";
        // Add array to end of list
        l.AddRange(a);
    }
}