using System;
public class jaggedarray{
	public static void Main(string[] args) 	{
		int[][] intJaggedArray = new int[2][]
                   { new int[3]{1, 2, 3},
                     new int[2]{4, 5}
                    };

		Console.WriteLine(intJaggedArray[0][0]); // 1
		Console.WriteLine(intJaggedArray[0][2]); // 3
		Console.WriteLine(intJaggedArray[1][1]); // 5	
		
		int[][][] intJaggedArray1 = new int[2][][]		{
			new int[2][]			{ 
				new int[3] { 1, 2, 3},
				new int[2] { 4, 5} 
			},
			new int[1][]
			{ 
				new int[3] { 7, 8, 9}
			}
		};

		Console.WriteLine(intJaggedArray1[0][0][0]); // 1
		Console.WriteLine(intJaggedArray1[0][1][1]); // 5
	
	}
}