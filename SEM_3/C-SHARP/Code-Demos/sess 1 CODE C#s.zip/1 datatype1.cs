using System;
					
public class datatype1
{
	public static void Main()
	{
		//implicitely typed variable
		var i = 10;
		Console.WriteLine("Type of i is {0}",i.GetType().ToString());
	
		var str = "Hello World!!";
		Console.WriteLine("Type of str is {0}", str.GetType().ToString());
	
		var d = 100.50d;
		Console.WriteLine("Type of d is {0}", d.GetType().ToString());
	
		var b = true;
		Console.WriteLine("Type of b is {0}", b.GetType().ToString());
	}
}
/*
Type of i is System.Int32
Type of str is System.String
Type of d is System.Double
Type of b is System.Boolean
*/