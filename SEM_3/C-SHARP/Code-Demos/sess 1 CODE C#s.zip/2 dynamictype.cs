using System;
					
public class dynamictype
{
	public static void Main()
	{
		dynamic dynamicVariable = 100;
		Console.WriteLine("Dynamic variable value: {0}, Type: {1}",dynamicVariable, dynamicVariable.GetType().ToString());
	
		dynamicVariable = "Hello World!!";
		Console.WriteLine("Dynamic variable value: {0}, Type: {1}", dynamicVariable, dynamicVariable.GetType().ToString());
	
		dynamicVariable = true;
		Console.WriteLine("Dynamic variable value: {0}, Type: {1}", dynamicVariable, dynamicVariable.GetType().ToString());
	
		dynamicVariable = DateTime.Now;
		Console.WriteLine("Dynamic variable value: {0}, Type: {1}", dynamicVariable, dynamicVariable.GetType().ToString());
		
		PrintValue("Hello World!!");
		PrintValue(100);
		PrintValue(100.50);
		PrintValue(true);
        	PrintValue(DateTime.Now);
		 Console.ReadKey();

	}
	public static void PrintValue(dynamic val)
	    {
	        Console.WriteLine(val);
    }
	
}

/*
Dynamic variable value: 100, Type: System.Int32
Dynamic variable value: Hello World!!, Type: System.String
Dynamic variable value: True, Type: System.Boolean
Dynamic variable value: 12/16/2019 4:42:26 PM, Type: System.DateTime
Hello World!!
100
100.5
True
12/16/2019 4:42:26 PM
*/