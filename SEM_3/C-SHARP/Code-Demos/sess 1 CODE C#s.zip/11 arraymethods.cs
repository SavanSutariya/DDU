using System;

public class arraymethods{
	public static void Main()	{
		string[] topic; 
  
        // Array implements the IsFixedSize property because
		//it is required by the System.Collections.IList interface. 
		
        topic = new string[] {"Array, ", "String, ", 
                               "Stack, ", "Queue, ", 
                        "Exception, ", "Operators"}; 
		Console.WriteLine("Result: " + topic.IsFixedSize); 
		Console.WriteLine("Length of topic: "+topic.Length);
		// Two-dimensional array 
		int[, ] intarray = new int[, ] { { 1, 2 }, 
				{ 3, 4 }, 
				{ 5, 6 }, 
				{ 7, 8 } }; 
		Console.WriteLine("Length: "+intarray.Length);
		Console.WriteLine("Long Length: "+intarray.LongLength); 
/*Array.Length property always returns the length of the type System.Int32 but 
Array.LongLength property always returns the length of the type System.Int64.*/	
		Console.WriteLine("Dimension of topic array: "+ topic.Rank);	
Console.WriteLine("Dimension of intarray: " + intarray.Rank);
            Console.ReadKey();

    } 

	
}



