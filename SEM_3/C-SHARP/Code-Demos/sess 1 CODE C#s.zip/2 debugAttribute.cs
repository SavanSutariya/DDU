#define PERLS
#undef DOT
using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        MethodA();
        MethodB();
    }
    
    [Conditional("PERLS")]
    static void MethodA()
    {
        Console.WriteLine(true);
    }
    
    [Conditional("DOT")]
    static void MethodB()
    {
        Console.WriteLine(false);
    }
}